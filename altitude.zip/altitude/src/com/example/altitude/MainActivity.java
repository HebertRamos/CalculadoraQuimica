package com.example.altitude;

import java.math.BigDecimal;

import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.widget.Button;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.app.Activity;
import android.view.Menu;

public class MainActivity extends Activity {
	Button btnGps;
	TextView txtLatitude;
	TextView txtLongitude;
	TextView txtAltitude;
	TextView txtPressao;
	GPSTracker gps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		txtLatitude = (TextView) findViewById(R.id.txtLatitude);
		txtLongitude = (TextView) findViewById(R.id.txtLongitude);
		txtAltitude = (TextView) findViewById(R.id.txtAltitude);
		txtPressao = (TextView) findViewById(R.id.txtPressao);

		btnGps = (Button) findViewById(R.id.btnGps);

		// show location button click event
		btnGps.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// create class object
				gps = new GPSTracker(MainActivity.this);

				// check if GPS enabled
				if (gps.canGetLocation()) {

					double latitude = gps.getLatitude();
					double longitude = gps.getLongitude();
					double altitude = gps.getAltitude();
					
					double pressaoAtmosfericaEmMilibar = 0; 
					double pressaoAtmosferiaEmAtm = 0;
					
					if (altitude != 0){
						pressaoAtmosfericaEmMilibar = 1013 - (altitude / 8);
						pressaoAtmosferiaEmAtm = 0.0009869232667 * pressaoAtmosfericaEmMilibar;
					}
					String lat = new Double(latitude).toString();
					txtLatitude.setText(lat);

					String lon = new Double(longitude).toString();
					txtLongitude.setText(lon);

					String alt = new Double(altitude).toString();
					txtAltitude.setText(alt);

					String press = new Double(pressaoAtmosferiaEmAtm)
							.toString();
					txtPressao.setText(press);

				} else {
					// can't get location
					// GPS or Network is not enabled
					// Ask user to enable GPS/network in settings
					gps.showSettingsAlert();
				}

			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
